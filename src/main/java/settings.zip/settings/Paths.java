/**
 * 
 */
package settings;

/**
 * @author RoManski
 *
 */
public enum Paths {

	CACHEDSPACES,PLOTS
}
